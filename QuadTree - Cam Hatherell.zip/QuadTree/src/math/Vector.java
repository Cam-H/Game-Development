package math;

public class Vector {
	
	private int xVel;
	private int yVel;
	
	
	private int xAccel;
	private int yAccel;
	
	public Vector(){
		xVel = 0;
		yVel = 0;
		
		xAccel = 0;
		yAccel = 0;
	}
	
	/********Getters***********/
	
	public int xVel(){
		return xVel;
	}
	
	public int yVel(){
		return yVel;
	}
	
	public int xAccel(){
		return xAccel;
	}
	
	public int yAccel(){
		return yAccel;
	}

}
