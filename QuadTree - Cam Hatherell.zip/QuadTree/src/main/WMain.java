package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.util.ArrayList;

import javax.swing.JFrame;

import math.Vector;

public class WMain extends Thread{

	static JFrame frame;
	static Mouse mouse;
	
	static int WIDTH, HEIGHT;
	
	
	static Quad map;
	
	static ArrayList<Blast> blasts;
	
	public void run(){
		
		while(true){
			
			render();
			//TODO: Remove after testing:
			
			try {
				Thread.sleep(1000/60);
			} catch (InterruptedException e) {}
		}
	}
	
	public void render(){
		BufferStrategy bs = frame.getBufferStrategy();
		
		if(bs == null){
			frame.createBufferStrategy(3);
			return;
		}
		
		Graphics g = bs.getDrawGraphics();
		
		///////////////////////////////////////////////////////
		
		g.setColor(new Color(0,0,0));
		g.fillRect(0, 0, WIDTH, HEIGHT);
		
		map.draw(g);
		
		for(int i = 0; i < blasts.size(); i++){
			blasts.get(i).draw(g);
		}
		
		///////////////////////////////////////////////////////
		
		g.dispose();
		bs.show();
	}
	
	public static void main(String[] args){
		
		frame = new JFrame();
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setUndecorated(true);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setVisible(true);
		
		mouse = new Mouse();
		
		frame.addMouseListener(mouse);
		frame.addMouseMotionListener(mouse);
		frame.addMouseWheelListener(mouse);

		
		WIDTH = frame.getWidth();
		HEIGHT = frame.getHeight();
		
		map = new Quad(WIDTH/2, HEIGHT/2, HEIGHT/2);
		map.split();
		
		blasts = new ArrayList<Blast>();
		blasts.add(new Blast(0, 200, 300, new Vector()));
		blasts.get(0).start();
		
		WMain renderer = new WMain();
		
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {}
		
		renderer.start();
		
		
		
	}
	
	/**********Getters*********/
	
	public static Quad map(){
		return map;
	}
}
