package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

public class Quad {
	
	private int ID;
	
	int cx;
	int cy;
	int radius;
	
	Quad topLeft;
	Quad topRight;
	Quad botRight;
	Quad botLeft;
	
	public Quad(){
		ID = 0;
	}
	public Quad(int cx, int cy, int radius){
		this.cx = cx;
		this.cy = cy;
		this.radius = radius;
		
		ID = 0;
	}
	
	/***********Getters*****************/
	
	public int ID(){
		return ID;
	}
	
	/************Setters***************/
	
	public void setID(int ID){
		this.ID = ID;
	}
	
	public boolean split(){
		
		if(radius/2 != 0){
			
			if(ID != 1){
				
				if(ID == 2){
					if(topLeft.ID() == 0){
						topLeft = new Quad(cx - radius/2, cy - radius/2, radius/2);
					}
					if(topRight.ID() == 0){
						topRight = new Quad(cx + radius/2, cy - radius/2, radius/2);
					}
					if(botRight.ID() == 0){
						botRight = new Quad(cx + radius/2, cy + radius/2, radius/2);
					}
					if(botLeft.ID() == 0){
						botLeft = new Quad(cx - radius/2, cy + radius/2, radius/2);
					}
					
					return true;
				}
				
				topLeft = new Quad(cx - radius/2, cy - radius/2, radius/2);
				topRight = new Quad(cx + radius/2, cy - radius/2, radius/2);
				botRight = new Quad(cx + radius/2, cy + radius/2, radius/2);
				botLeft = new Quad(cx - radius/2, cy + radius/2, radius/2);
				
				
				ID = 2;
			}
			
			
			return true;
		}
		
		return false;
	}
	
	public void destroy(int exX, int exY, int exRadius){

		if(ID != 1){
			if(isColliding(exX, exY, exRadius)){
				if(split()){
					
					topLeft.destroy(exX, exY, exRadius);
					topRight.destroy(exX, exY, exRadius);
					botRight.destroy(exX, exY, exRadius);
					botLeft.destroy(exX, exY, exRadius);
					
					
					if(topLeft.ID() == 1 && topRight.ID() == 1 && botRight.ID() == 1 && botLeft.ID() == 1){
						ID = 1;
					}
					
					return;
				}
				
				ID = 1;

			}else{
				return;
			}
		}
		
		
	}
	
	private boolean isColliding(int exX, int exY, int exRadius){
		
		int xDist = Math.abs(exX - cx);
		int yDist = Math.abs(exY - cy);
		
		if(xDist > exRadius + radius || yDist > exRadius + radius){
			return false;
		}
		
		//Checks whether the quad is entirely inside the blast
		
		if(xDist <= radius || yDist <= radius){
			return true;
		}
		
		double cornerDist = Math.pow(xDist - radius, 2) + Math.pow(yDist - radius, 2);
		
		if(cornerDist <= Math.pow(exRadius, 2)){
			return true;
		}
		
		return false;
		
	}
	
	public void draw(Graphics g){
		
		//Graphics2D g2 = (Graphics2D)g;
		
		//g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		switch(ID){
		case 0://Ground
			g.setColor(new Color(0,255,0));
			break;
		case 1://Sky
			g.setColor(new Color(0,0,255));
			break;
		case 2://Split
			topLeft.draw(g);
			topRight.draw(g);
			botRight.draw(g);
			botLeft.draw(g);
			return;
		}
		
		g.fillRect(cx-radius-1, cy-radius-1, radius*2+2, radius*2+2);
		g.setColor(Color.black);
		g.drawRect(cx - radius, cy - radius, radius*2, radius*2);

	}
}
