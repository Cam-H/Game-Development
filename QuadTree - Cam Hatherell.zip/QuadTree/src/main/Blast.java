package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import math.Vector;

public class Blast extends Thread{
	
	private final int ID;
	
	//Center
	private int cx;
	private int cy;
	
	private int radius;
	
	//Size modifiers
	private int growth;
	private int subGrowth;//Should always be negative
	
	//Velocities
	private int xVel;
	private int yVel;
	
	//Accelerations
	private int xAccel;
	private int yAccel;
	
	private long delay;
	
	public Blast(int ID, int cx, int cy, Vector traj){
		this.ID = ID;
		
		this.cx = cx;
		this.cy = cy;
		
		this.xVel = traj.xVel();
		this.yVel = traj.yVel();
		
		this.xAccel = traj.xAccel();
		this.yAccel = traj.yAccel();
		
		initialize(ID);
	}
	
	private void initialize(int ID){
		switch(ID){
		case 0:
			
			radius = 5;
			growth = 20;
			subGrowth = -1;
			
			delay = 120;
			
			break;
		}
	}
	
	public void run(){
		
		while(radius + growth > 0){
			
			cx += xVel;
			cy += yVel;
			
			xVel += xAccel;
			yVel += yAccel;
			
			if(delay <= 0){
				radius += growth;
				growth += subGrowth;
				
				WMain.map().destroy(cx, cy, radius);
				//doCollision
			}else{
				delay--;
			}
			
			try {
				Thread.sleep(1000/60);
			} catch (InterruptedException e) {}
		}
	}
	
	public void draw(Graphics g){

		Graphics2D g2 = (Graphics2D)g;
		
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		
		switch(ID){
		case 0:
			g.setColor(new Color(255,0,0));
			break;
		}
		
		g2.fillOval(cx - radius, cy - radius, radius * 2, radius * 2);
	}
}
